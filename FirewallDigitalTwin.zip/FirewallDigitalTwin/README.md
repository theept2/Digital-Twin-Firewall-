# Firewall Digital Twin

**Course:** CYB 301 – Digital Twin Project #2

## Project Overview
This project uses Python object-oriented programming to create a simple digital twin of a firewall. The program tracks the firewall's state, stores allowed and blocked IP addresses, and simulates inspecting network packets.

> **Note:** This is an educational simulation. It does not filter real network traffic or replace a production firewall.

## Attributes
- `name`: Name of the simulated firewall.
- `status`: Whether the firewall is `ON` or `OFF`.
- `blocked_ips`: List of IP addresses the simulation blocks.
- `allowed_ips`: List of IP addresses the simulation allows.
- `packets_inspected`: Count of packets inspected while the firewall is on.

## Methods
- `start()`: Turns the firewall on.
- `stop()`: Turns the firewall off.
- `block_ip(ip_address)`: Adds an IP address to the blocked list.
- `allow_ip(ip_address)`: Adds an IP address to the allowed list.
- `inspect_packet(ip_address)`: Simulates a packet inspection and prints the result.
- `display_status()`: Prints the firewall's current attributes.

## How to Run
1. Install Python 3 if it is not already installed.
2. Download or clone this repository.
3. Open a terminal in the project folder.
4. Run:

   ```bash
   python firewall_digital_twin.py
   ```

   On some systems, use `python3 firewall_digital_twin.py`.

## Example Behavior
The demonstration creates a firewall object, starts it, adds allowed and blocked IP addresses, inspects packets, displays the updated state, and then stops the firewall.

## Files
- `firewall_digital_twin.py` — Python source code.
- `execution_screenshot.png` — Screenshot-style image of the program's successful console output.
- `README.md` — Project documentation.
